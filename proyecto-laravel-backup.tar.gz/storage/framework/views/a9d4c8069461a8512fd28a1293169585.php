<!DOCTYPE html>
<html>
<head>
    <title>Servicios</title>
</head>
<body>
    <h1>Servicios</h1>
    <p>Aquí describimos los servicios que ofrecemos.</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\csi\resources\views/servicios.blade.php ENDPATH**/ ?>