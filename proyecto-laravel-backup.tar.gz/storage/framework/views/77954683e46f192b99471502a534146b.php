<footer class="footer">
    <div class="contacto_footer">
        <h2>Contáctanos</h2>
        <p>conectasisas@gmail.com</p>
        <p>3217235094</p>
    </div>
    <a href="<?php echo e(url('/')); ?>">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo CSI" width="100px">
    </a>
    <div class="redes_footer">
        <a href="https://www.facebook.com/">
            <img src="<?php echo e(asset('images/facebook.png')); ?>" alt="Facebook" width="40px">
        </a>
        <a href="https://twitter.com/">
            <img src="<?php echo e(asset('images/twitter.png')); ?>" alt="Twitter" width="40px">
        </a>
        <a href="https://www.instagram.com/">
            <img src="<?php echo e(asset('images/istagram.png')); ?>" alt="Instagram" width="30px">
        </a>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\Laravel\csi\resources\views/layouts/footer.blade.php ENDPATH**/ ?>