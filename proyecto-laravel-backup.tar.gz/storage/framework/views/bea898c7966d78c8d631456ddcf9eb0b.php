<?php $__env->startSection('title', 'login'); ?>

<?php $__env->startSection('content'); ?>
<body>
    <div class="loginclass">
        <div class="loginform">
            <h2>Inicio de sesión</h2>
            <form method="post" action="loginAuth.php">
                <div class="col-12">
                    <input type="text" class="login-sec-01-input" name="email" placeholder="INGRESA TU EMAIL">
                </div>
                <div class="col-12">
                    <input type="password" class="login-sec-01-input" name="password" placeholder="INGRESA TU CONTRASEÑA*">
                </div>
                <div class="col-12">
                    <button type="submit" class="global-02-bnt">INICIAR SESION →</button>
                </div>
            </form>
        </div>
    </div>
</body>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\csi\resources\views/login.blade.php ENDPATH**/ ?>