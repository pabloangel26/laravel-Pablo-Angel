<footer class="footer">
    <div class="contacto_footer">
        <h2>Contáctanos</h2>
        <p>conectasisas@gmail.com</p>
        <p>3217235094</p>
    </div>
    <a href="{{ url('/') }}">
        <img src="{{ asset('images/logo.png') }}" alt="Logo CSI" width="100px">
    </a>
    <div class="redes_footer">
        <a href="https://www.facebook.com/">
            <img src="{{ asset('images/facebook.png') }}" alt="Facebook" width="40px">
        </a>
        <a href="https://twitter.com/">
            <img src="{{ asset('images/twitter.png') }}" alt="Twitter" width="40px">
        </a>
        <a href="https://www.instagram.com/">
            <img src="{{ asset('images/istagram.png') }}" alt="Instagram" width="30px">
        </a>
    </div>
</footer>
