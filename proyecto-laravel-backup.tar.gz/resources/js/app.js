import './bootstrap';

// resources/js/app.js
import '../css/app.css';  // Asegúrate de que la ruta sea correcta
